<?php

$i18n = Array(
	'module-convead' => 'Convead',

	'header-convead-config' => 'Настройки',
	'group-convead_config' => 'Настройки',
	'option-api_key' => 'API-ключ',

	'perms-convead-convead' => 'Отправка данных в convead'
);
