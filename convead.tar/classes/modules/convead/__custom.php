<?php
	abstract class __custom_convead {
		//TODO: Write here your own macroses
	};
?>