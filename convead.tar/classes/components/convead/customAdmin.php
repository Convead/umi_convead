<?php

class ConveadCustomAdmin {
	//TODO: Write here your own macroses (admin mode)
};

?>