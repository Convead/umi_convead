<?php
  $permissions = Array(
    'convead' => array(
      'getConveadScript',
      'onOrderRefreshConveadUpdateCart',
      'onOrderStatusChangedConveadOrderState',
      'onSystemModifyObjectConvead',
      'onSystemModifyPropertyValueConvead'
    ),
  );
?>
