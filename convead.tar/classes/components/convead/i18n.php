<?php

$i18n = [
	'module-convead' => 'Convead',

	'header-convead-config' => 'Настройки',
	'group-convead_config' => 'Настройки',
	'option-app_key' => 'APP KEY вашего аккаунта convead',

	'perms-convead-convead' => 'Отправка данных в convead'
];
