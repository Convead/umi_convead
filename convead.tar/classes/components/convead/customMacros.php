<?php

class ConveadCustomMacros {
		//TODO: Write here your own macroses
};

?>