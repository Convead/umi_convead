<?php
	$permissions = Array(
		'convead' => array(
			'getConveadScript',
			'onOrderRefreshConveadUpdateCart',
			'onOrderStatusChangedConveadPurchase'
		),
	);
?>
