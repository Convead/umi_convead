<?php

$C_LANG = Array();

$C_LANG['module_name'] = "Convead";

$C_LANG['module_title'] = "Convead";
$C_LANG['module_description'] = "";

$LANG_EXPORT = Array();
?>